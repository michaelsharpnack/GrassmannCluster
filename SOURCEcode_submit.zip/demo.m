clc
clear
addpath('./src')

%% Load TCGA BRCA data
load('DATA/BRCA.mat');

%% Normalize data 
[BRCAGE_norm] = Standard_Normalization(BRCAGE');
[BRCAMETH_norm] = Standard_Normalization(BRCAMETH');
[BRCAMIR_norm] = Standard_Normalization(BRCAMIR');
clear BRCAGE  BRCAMETH BRCAMIR

%% construct the graphs for each data type
options = [];
options.NeighborMode = 'KNN';
options.k = 30; 
options.WeightMode = 'HeatKernel';
options.t = 100;

W_GE   = full(constructW(BRCAGE_norm,  options));
W_MIR  = full(constructW(BRCAMIR_norm, options));
W_METH = full(constructW(BRCAMETH_norm,options));

%% Integrative clustering 
n = size(W_GE, 1);

W_COMBINE = zeros(n, n, 3); 
W_COMBINE(:,:,1) = W_GE(:,:);
W_COMBINE(:,:,2) = W_MIR(:,:);
W_COMBINE(:,:,3) = W_METH(:,:);

% set the number of clusters
K = 5; 
[idx_COMBINE,Vk, Lnew] = sc_ml(W_COMBINE, K, 0.5);

displayClusters(Vk*Vk',idx_COMBINE);











